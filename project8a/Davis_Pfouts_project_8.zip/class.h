#include <iostream>
#include <fstream>
using namespace std;

////////////////////////////////////////////////////////////////////
class card{
	friend class player;
	public:

		card();
		card(const card&);
		~card();
		void setlo(const string&);
		  card& operator=(const card&);
          bool operator==(const card&) const;
          bool operator>(const card&) const;
          bool operator>=(const card& comp) const;
		  friend ostream& operator<<(ostream&, card&);
          friend ifstream& operator>>(ifstream&, card&);

	private:
	string suit;
	string rank;
	string location;
	int value;
	
/////////////////////////////////////////////////////////////////////
	

};

class player
{
	public:
		player();
		~player();
		 //void player::sethand( card&);
		 friend ostream& operator<<(ostream&, player&);
         friend ifstream& operator>>(ifstream&, player&);

	private:
	string name;
	card* hand[5];
	float bet;
	
};



