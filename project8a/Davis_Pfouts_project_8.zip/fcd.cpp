//Project 8 Five Card Draw
//Davis Pfouts 


#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <ctime>
#include "class.h"
using namespace std;

int main()
{
	//deck for cards unshuffled
	card* dptr=NULL;
	dptr= new card[52];

	ifstream fin;
	ofstream fout;
	fin.clear();
	fin.open("deck");
//read in deck unshuffled
	for(int i=0; i<52; i++)	{
fin>>dptr[i];
dptr[i].setlo("unshuffled");

							}
	
	fin.close();

//create aray for all players at table
	player* table = new player[8];

	fin.clear();
	fin.open("players");

for (int i=0 ; i<8; i++){

	fin>> table[i];
						}

card* deck = new card[52];
//deck for shuffled cards


int k=0;

	//MENUE
char choice;
	while (choice != 6)
	{
		cout<< ".....FIVE CARD DRAW..... \n";
		cout<< "============================ \n" << "\n";
		cout<< "1) Print Deck \n";
		cout<< "2) Print Table \n";
		cout<< "3) Shuffle Deck \n";
		cout<< "4) Print Shuffled Deck \n";
		cout<< "5) Deal \n";
		cout<< "6) QUIT \n";
		cout<< "Please Enter Your Selection: \n";
		cin>> choice;
		cout<< endl;

	switch (choice)
	{
case '1':

for(int i=0; i<52; i++)	{
	cout<<dptr[i];
						}

break;

case '2':

	for (int i=0; i<8; i++)	{
		cout<< table[i];
							}

break;

case '3':

//srand( time(NULL) );

for(int i=0; i<52; i++){
	deck[i]=dptr[i];
	deck[i].setlo("shuffled");
}


	
//int random = ( rand() % 52 );
     
        
  for (int i=0; i<(52-1); i++) {
            int r = i + (rand() % (52-i)); 
            card temp = deck[i]; 
            deck[i] = deck[r]; 
            deck[r] = temp;
        }


	//deck[i]= dptr[];
cout<< "DECK SHUFFLED! \n";

break;

case'4':
for(int i=0; i<52; i++){
	cout<<deck[i]<< "\n";
}
break;

case '5':

/*for(int j=0 ; j<8; j++){
	
	
table[j].sethand(deck[k]);
k++;
	}*/

break;

case '6':
	cout<< "Goodbye" << endl;
	choice = 6;
		
break;

	default: cout<< choice << "  is not a valid entry \n";
		 cout<< endl;
	break;


	}

}

	delete[] deck;
//test area
if(deck[0]>deck[1]){
	cout<< " is greater than"<<endl;
}

if(deck[0]>=deck[1]){
	cout<<" is greater than"<< endl;
}
	return 0;

}