#include "class.h"
#include <cstdlib>
#include <iostream>
#include <fstream>
using namespace std;

player::player()
{
	name = "first last";

card* hand= new card[5];

	bet = 0.0;

}
/////////////////////////////////////////////////////////////////////////////

player::~player()
{
	name="";
	for(int i =0 ; i<5 ; i++){
	
	delete hand[i];
							}
	bet = 0.0;

}
//////////////////////////////////////////////////////////////////////////////

//void player::sethand( card& a){



//hand[0]= a;


//}
//////////////////////////////////////////////////////////////////////////////
ostream& operator<< (ostream& o, player& a)
{
o << "name: " << a.name << "\t hand: "<< a.hand[0]<< "\t  bet: " << a.bet<< endl ;


}
/////////////////////////////////////////////////////////////////////////////
ifstream& operator>> (ifstream& i , player& a)
{

i >> a.name >>a.name ;



}


//////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////


card::card()
{
	suit="";
	rank="";
	location="";
	value=0;

}

///////////////////////////////////////////////////////////////////////////////////

card::~card()
{
	suit="";
	rank="";
	location="";
	value =0;
	
}

////////////////////////////////////////////////////////////////////////////////////

card::card(const card& t)
{

	suit = t.suit ;
	
	rank = t.rank ;

	location = t.location ;

	value = t.value;
}

////////////////////////////////////////////////////////////////////////////////////

void card::setlo(const string& a){

	location = a;
}

///   ///   ///   ///   ///   ///   ///   ///   ///   ///   ///

ostream& operator<< (ostream& o, card& a)
{
o << "  suit: " << a.suit << "\t  rank: "<< a.rank <<"\t  location: " << a.location << endl;


}

///   ///   ///   ///   ///   ///   ///   ///   ///   ///   ///

ifstream& operator>> (ifstream& i , card& a)
{

i >> a.suit >> a.rank >> a.value ;
a.location = "unshuffled";



}

///   ///   ///   ///   ///   ///   ///   ///   ///   ///   ///

card& card::operator=( const card &cpy)
{
	
	suit = cpy.suit;
	rank = cpy.rank;
	value = cpy.value;
	

return *this;
}

///   ///   ///   ///   ///   ///   ///   ///   ///   ///   ///

 bool card::operator==(const card& comp) const
{
if(comp.value == value)	
	{
	return true;
	}

else	{
return false;
	}
}
///   ///   ///   ///   ///   ///   ///   ///   ///   ///   ///

bool card::operator>(const card& comp)const
{
	if (comp.value > value)
	{
		return true;
		cout<< "card is greater \n";
	}
else {cout<< "card is not greater \n";
return false;}
}

bool card::operator>=(const card& comp) const
{
	if(comp.value > value || comp.value== value){
		cout<<"card is greater or equal \n";
		return true;
	}
else{cout<< "card is less than \n"; 
return false;}
}